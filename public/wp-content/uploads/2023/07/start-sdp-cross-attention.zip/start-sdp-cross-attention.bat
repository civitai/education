@echo off

REM Check if venv exists
IF NOT EXIST "venv" (
    REM Create venv and install requirements
    python -m venv venv
    .\venv\Scripts\pip install -r requirements.txt
)

REM Activate venv and run main.py
CALL .\venv\Scripts\Activate.bat
python main.py --use-pytorch-cross-attention

REM Deactivate venv when done
CALL .\venv\Scripts\deactivate.bat